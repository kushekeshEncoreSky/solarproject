<?php
echo "hello mayank sir";
?>